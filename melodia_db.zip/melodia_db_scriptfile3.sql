/* Resets the number of downloads weekly to show trending songs during that period. */
UPDATE SONG
SET num_downloads = 0 
WHERE num_downloads != 0;

/* Finds the most popular pop song by downloads. */
SELECT max(num_downloads) AS Most_Played 
FROM SONG
GROUP by genre
HAVING genre = ‘Pop’;

/*Displays a list of artists whose label companies are located at New York or Atlanta.
SELECT name
FROM ARTIST
WHERE artist_id IN (Select label_id
	FROM Label
	WHERE hq_location = ‘New York, NY’ OR hq_location = ‘Atlanta, GA’);

/* Searching for an song name that starts with the letter M */
SELECT song_name
FROM SONG
WHERE name like “N%”;


/* Displays the album table */
SELECT * from ALBUM;