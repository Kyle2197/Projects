CREATE TABLE ARTIST(
  artist_id int (5) NOT NULL,
  name varchar (50),
  number_of_songs int (4),
  number_of_albums int (4),
  PRIMARY KEY(artist_id)
);

CREATE TABLE ALBUM_INFO(
  album_songs int (5) NOT NULL,
  album_name varchar (50) NOT NULL,
  album_id int (5) NOT NULL,
  PRIMARY KEY(album_songs)
);

CREATE TABLE HEADQUARTERS(
  hq_name varchar (50) NOT NULL,
  hq_location varchar (50),
  PRIMARY KEY(hq_name)
);

create table LABEL (
  label_id int(5) NOT NULL,
  label_type varchar(50),
  label_name varchar(50),
  hq_name varchar(50),
  PRIMARY KEY (label_id),
  FOREIGN KEY (hq_name)
    REFERENCES HEADQUARTERS(hq_name)
);

create table ALBUM ( 
	album_id int (5) NOT NULL,
	album_name varchar(50),
	album_songs int (5),
 PRIMARY KEY (album_id)
);

create table SONG (
	song_id int (5) NOT NULL,
	album_id int (5),
	num_downloads int (5),
	ratings int (1),
	song_length int (5) ,
	song_name varchar (50),
  PRIMARY KEY (song_id),
  FOREIGN KEY (album_id) 
    REFERENCES ALBUM (album_id)
);

create table SONG_INFO (
	artist_id int (5) NOT NULL,
	song_id int (5) NOT NULL,
  PRIMARY KEY(artist_id,song_id),
  FOREIGN KEY(artist_id) REFERENCES ARTIST(artist_id),
  FOREIGN KEY(song_id) REFERENCES SONG(song_id)
);

create table SONG_LANGUAGE (
	song_id int (5),
	language varchar (50) NOT NULL,
  PRIMARY KEY(language),
  FOREIGN KEY(song_id) REFERENCES SONG(song_id)
);

create table SONG_GENRE (
	song_id int (5) NOT NULL,
	genre varchar (50) NOT NULL,
  PRIMARY KEY(genre),
  FOREIGN KEY (song_id)
  REFERENCES SONG(song_id)
);

create table PARTNERSHIP (
  artist_id int(5),
	label_id int(5),
  PRIMARY KEY(artist_id,label_id),
  FOREIGN KEY(artist_id) REFERENCES ARTIST(artist_id),
  FOREIGN KEY(label_id) REFERENCES LABEL(label_id));

create table INDEPENDENT_LABEL (
	ilabel_id int(5) NOT NULL,
	localized_location varchar(50),
  PRIMARY KEY(ilabel_id));

create table MAJOR_LABEL (
	mlabel_id int (5) NOT NULL,
	international_location varchar(50),
  PRIMARY KEY(mlabel_id));

create table ALBUM_CREATOR (
	album_id int (5) NOT NULL,
	artist_id int (5) NOT NULL,
  PRIMARY KEY(artist_id,album_id),
  FOREIGN KEY(artist_id) REFERENCES ARTIST(artist_id),
  FOREIGN KEY(album_id) REFERENCES SONG(album_id));
  
Insert into ARTIST values (1, 'John Smith' ,15 ,2);
Insert into ARTIST values (2, 'Samantha Franklin', 13, 1);
Insert into ARTIST values (3, 'The Rolling Bones', 32, 3);
Insert into ARTIST values (4, 'Kodak White', 20 ,3);
Insert into ARTIST values (5, 'Mario Hezonjaa', 66, 2);
Insert into ARTIST values (6, 'Martin Gay', 20, 3);
Insert into ARTIST values (7, 'Bobby Wonder', 9, 1);
Insert into ARTIST values (8, 'Lead Zeppelin', 30, 7);
Insert into ARTIST values (9, 'Rob Moss', 19, 3);
Insert into ARTIST values (10, 'The Rotating Stone', 25, 2);
Insert into ARTIST values (11, '21 Cabbage', 4252,4);
Insert into ARTIST values (12, 'Young God',168, 7);
Insert into ARTIST values (13, 'Frank Seaman', 9, 1 );
Insert into ARTIST values (14, 'Afolabi Afua', 87, 4 );
Insert into ARTIST values (15, 'Aaron Blake', 16, 2);
Insert into ARTIST values (16, 'Rick Jagger', 98, 30);
Insert into ARTIST values (17, 'Mary Lamb', 23, 2);
Insert into ARTIST values (18, 'Elva Presley', 50, 6);
Insert into ARTIST values (19, 'Danielle Bregooli', 36, 3);
Insert into ARTIST values (20,'Elva Elvarose', 40, 2);

Insert into ALBUM_INFO values (1, 'Sinner', 1 ); 
Insert into ALBUM_INFO values (2, 'Golden Age of Country', 2); 
Insert into ALBUM_INFO values (3, 'Everly Brothers', 3); 
Insert into ALBUM_INFO values (4, 'Life of Kanye Vol. 2', 4 ); 
Insert into ALBUM_INFO values (5, 'The Way', 5); 
Insert into ALBUM_INFO values (6, 'Soy estadounidense', 6); 
Insert into ALBUM_INFO values (7, 'Frost Zero', 7); 
Insert into ALBUM_INFO values (8, 'True Grit', 8); 
Insert into ALBUM_INFO values (9, 'Sour Patch Kids', 9); 
Insert into ALBUM_INFO values (10, 'Swap Shop', 10); 
Insert into ALBUM_INFO values (11, 'Golden Dreams Vol. 3', 11); 
Insert into ALBUM_INFO values (12, 'Acarus 1', 12); 
Insert into ALBUM_INFO values (13, 'Swap Shop', 13); 
Insert into ALBUM_INFO values (14, 'Verborge Leaf Village', 14); 
Insert into ALBUM_INFO values (15, 'Deutschland ist Land', 15); 
Insert into ALBUM_INFO values (16, '86-75-309', 16); 
Insert into ALBUM_INFO values (17, 'Two-door Benz', 17);
Insert into ALBUM_INFO values (18, 'Turbo Melts Steel Beams', 18); 
Insert into ALBUM_INFO values (19, 'Alexander Hamilton', 19); 
Insert into ALBUM_INFO values (20, 'Mi tragedia abandonada', 20); 

Insert into HEADQUARTERS values ('Nikki Music Deals', 'Sanford, FL');
Insert into HEADQUARTERS values ('Jeff Ram Productions', 'Atlanta, GA');
Insert into HEADQUARTERS values ('West Coast Rivals', 'San Diego, CA');
Insert into HEADQUARTERS values ('East Coast Champs', 'Warminster, PA');
Insert into HEADQUARTERS values ('BWA Productions', 'Atlanta, GA');
Insert into HEADQUARTERS values ('International Stars', 'New York, NY');
Insert into HEADQUARTERS values ('International Moons', 'Manhattan, NY');
Insert into HEADQUARTERS values ('Futuristic Records', 'Gary, IN');
Insert into HEADQUARTERS values ('University Musical Group', 'Santa Monica, CA');
Insert into HEADQUARTERS values ('Rikki Record Deals', 'Sanford, FL');
Insert into HEADQUARTERS values ('Hot Dough Records','Greensboro,NC');
Insert into HEADQUARTERS values ('Uni Musi', 'Santa Monica, CA');
Insert into HEADQUARTERS values ('MegaMusic Records','Toronto, ON');
Insert into HEADQUARTERS values ('League of Heroes', 'Silicon Valley, CA');
Insert into HEADQUARTERS values ('Black/Red/Yellow', 'Hollywood, CA'); 
Insert into HEADQUARTERS values ('Sunshine & Peaches', 'Miami, FL');
Insert into HEADQUARTERS values ('League of Something', 'Silicon Valley, CA');
Insert into HEADQUARTERS values ('Young & Wild', 'Miami, FL');
Insert into HEADQUARTERS values ('Hussein Bolt Inc.', 'Central City, IA');
Insert into HEADQUARTERS values ('International Sunshine', 'New York, NY');

Insert into LABEL values (1,'Major','JAR Records', 'Hot Dough Records');  
Insert into LABEL values (2,'Major', 'Y200', 'West Coast Rivals');  
Insert into LABEL values (3,'Major','LYMS','Hot Dough Records');  
Insert into LABEL values (4,'Independent','Hi Mom Music','BWA Productions');  
Insert into LABEL values (5,'Major','GOAT Records','Jeff Ram Productions');  
Insert into LABEL values (6,'Major','Rae Shimer','University Musical Group');  
Insert into LABEL values (7,'Independent', 'AVS Records', 'International Stars');  
Insert into LABEL values (8,'Major','Bro Era', 'East Coast Champs');  
Insert into LABEL values (9,'Major','Mega','MegaMusic Records');  
Insert into LABEL values (10,'Independent', 'Salty Spitoon', 'Black/Red/Yellow');  
Insert into LABEL values (11,'Major','Spin Records', 'International Stars');  
Insert into LABEL values (12,'Major','Heat Hits', 'BWA Productions');  
Insert into LABEL values (13,'Independent', 'Major Intel', 'Hot Dough Records');  
Insert into LABEL values (14,'Independent', 'Rasta Jamz', 'Hussein Bolt Inc.');  
Insert into LABEL values (15,'Major', 'CBB Radio','West Coast Rivals' );  
Insert into LABEL values (16,'Major','ABC Records', 'International Stars' );  
Insert into LABEL values (17,'Independent', 'Yami Muta', 'Nikki Music Deals' );  
Insert into LABEL values (18,'Major','Pizza Playlist','Hot Dough Records');  
Insert into LABEL values (19,'Independent','Juke Jamz','University Musical Group');  
Insert into LABEL values (20,'Major','Alright Alright Records','Sunshine & Peaches');   

Insert into ALBUM values (1, 'Prismatic', 15);
Insert into ALBUM values (2, 'Banana', 2);
Insert into ALBUM values (3, 'Born Yesterday', 13);
Insert into ALBUM values (4, 'Illuminate', 9);
Insert into ALBUM values (5, 'Thrilled', 14);
Insert into ALBUM values (6, 'The End', 8);
Insert into ALBUM values (7, 'Seven', 7);
Insert into ALBUM values (8, 'Beyond the Horizon', 7);
Insert into ALBUM values (9, 'Believe', 6);
Insert into ALBUM values (10, 'Arcane', 5);
Insert into ALBUM values (11, 'Please Please Plz', 4);
Insert into ALBUM values (12, 'Various Dog Noises', 9);
Insert into ALBUM values (13, 'Journey To Pop-hood', 12);
Insert into ALBUM values (14, 'Blompot', 15);
Insert into ALBUM values (15, 'The Death of Individuality', 3);
Insert into ALBUM values (16, 'Staying in a Strangers House', 2);
Insert into ALBUM values (17, 'Religion Is A Sham', 5 );
Insert into ALBUM values (18, 'Faith', 12);
Insert into ALBUM values (19, 'I Made Dr. Phil', 3);
Insert into ALBUM values (20, 'From The Ashes', 17);

Insert into SONG values (1, 1, 3123, 3, 187, 'False Prison');
Insert into SONG values (2, 2, 12, 1, 233, 'Just A Farm Girl');
Insert into SONG values (3, 3, 202, 4, 193, 'American Gypsy');
Insert into SONG values (4, 4, 10745, 5, 180, 'Bus-stop Trapping');
Insert into SONG values (5, 5, 33321, 1, 155, 'Friday');
Insert into SONG values (6, 6, 4234, 4, 123, 'Hands Off My Firecracker');
Insert into SONG values (7, 7, 777, 3, 77, 'Seven');
Insert into SONG values (8, 8, 24234, 4, 183, 'Violet Heaven');
Insert into SONG values (9, 9, 32145, 3, 173, 'Fear of Fire');
Insert into SONG values (10,10, 124, 1, 40, 'Intro to C');
Insert into SONG values (11,11, 23522, 5, 154, 'Cabbage Time');
Insert into SONG values (12, 12, 4341, 4, 200, 'New Era, New God');
Insert into SONG values (13, 13, 9850, 1, 120, 'Non Stop Pop');
Insert into SONG values (14, 14, 12556, 4, 186, 'Blompot Vrou');
Insert into SONG values (15, 15, 235, 1, 174, 'Mainstream Sellout');
Insert into SONG values (16, 16, 24112, 2, 231, 'Hotel Florida');
Insert into SONG values (17, 17, 4234, 2, 213, 'Drunk In Hate');
Insert into SONG values (18, 18, 123, 4, 133, 'I Will Persevere');
Insert into SONG values (19, 19, 5324, 5, 214, 'Catch Me Outside');
Insert into SONG values (20, 20, 32423, 5, 123, 'Losing My Mind');

Insert into SONG_INFO values (1, 1);
Insert into SONG_INFO values (2, 2);
Insert into SONG_INFO values (3, 3);
Insert into SONG_INFO values (4, 4);
Insert into SONG_INFO values (5, 5);
Insert into SONG_INFO values (6, 6);
Insert into SONG_INFO values (7, 7);
Insert into SONG_INFO values (8, 8);
Insert into SONG_INFO values (9, 9);
Insert into SONG_INFO values (10, 10);
Insert into SONG_INFO values (11, 11);
Insert into SONG_INFO values (12, 12);
Insert into SONG_INFO values (13, 13);
Insert into SONG_INFO values (14, 14);
Insert into SONG_INFO values (15, 15);
Insert into SONG_INFO values (16, 16);
Insert into SONG_INFO values (17, 17);
Insert into SONG_INFO values (18, 18);
Insert into SONG_INFO values (19, 19);
Insert into SONG_INFO values (20, 20);


Insert into SONG_LANGUAGE values (1, 'English');
Insert into SONG_LANGUAGE values (2, 'English');
Insert into SONG_LANGUAGE values (3, 'English');
Insert into SONG_LANGUAGE values (4, 'English');
Insert into SONG_LANGUAGE values (5, 'English');
Insert into SONG_LANGUAGE values (6, 'Spanish');
Insert into SONG_LANGUAGE values (7, 'Chinese');
Insert into SONG_LANGUAGE values (8, 'English');
Insert into SONG_LANGUAGE values (9, 'English');
Insert into SONG_LANGUAGE values (10, 'English');
Insert into SONG_LANGUAGE values (11, 'English');
Insert into SONG_LANGUAGE values (12, 'English');
Insert into SONG_LANGUAGE values (13, 'English');
Insert into SONG_LANGUAGE values (14, 'Afrikaans');
Insert into SONG_LANGUAGE values (15, 'German');
Insert into SONG_LANGUAGE values (16, 'English');
Insert into SONG_LANGUAGE values (17, 'English');
Insert into SONG_LANGUAGE values (18, 'English');
Insert into SONG_LANGUAGE values (19, 'English');
Insert into SONG_LANGUAGE values (20, 'Spanish');


Insert into SONG_GENRE values (1, 'Metal');
Insert into SONG_GENRE values (2, 'Country');
Insert into SONG_GENRE values (3, 'Country');
Insert into SONG_GENRE values (4, 'Rap');
Insert into SONG_GENRE values (5, 'Pop');
Insert into SONG_GENRE values (6, 'Country');
Insert into SONG_GENRE values (7, 'Rap');
Insert into SONG_GENRE values (8, 'Rock');
Insert into SONG_GENRE values (9, 'Dubstep');
Insert into SONG_GENRE values (10, 'Techno');
Insert into SONG_GENRE values (11, 'Rap');
Insert into SONG_GENRE values (12, 'Alternative Rap');
Insert into SONG_GENRE values (13, 'Rap');
Insert into SONG_GENRE values (14, 'Reggae');
Insert into SONG_GENRE values (15, 'Rock');
Insert into SONG_GENRE values (16, 'Pop');
Insert into SONG_GENRE values (17, 'Pop');
Insert into SONG_GENRE values (18, 'Pop');
Insert into SONG_GENRE values (19, 'R&B');
Insert into SONG_GENRE values (20, 'Rock');

Insert into PARTNERSHIP values (1, 1);
Insert into PARTNERSHIP values (2, 2);
Insert into PARTNERSHIP values (3, 3);
Insert into PARTNERSHIP values (4, 4);
Insert into PARTNERSHIP values (5, 5);
Insert into PARTNERSHIP values (6, 6);
Insert into PARTNERSHIP values (7, 7);
Insert into PARTNERSHIP values (8, 8);
Insert into PARTNERSHIP values (9, 9);
Insert into PARTNERSHIP values (10, 10);
Insert into PARTNERSHIP values (11, 11);
Insert into PARTNERSHIP values (12, 12);
Insert into PARTNERSHIP values (13, 13);
Insert into PARTNERSHIP values (14, 14);
Insert into PARTNERSHIP values (15, 15);
Insert into PARTNERSHIP values (16, 16);
Insert into PARTNERSHIP values (17, 17);
Insert into PARTNERSHIP values (18, 18);
Insert into PARTNERSHIP values (19, 19);
Insert into PARTNERSHIP values (20, 20);

Insert into INDEPENDENT_LABEL values (1, 'New York, NY');
Insert into INDEPENDENT_LABEL values (2, 'Miami, FL');
Insert into INDEPENDENT_LABEL values (3, 'San Diego, CA');
Insert into INDEPENDENT_LABEL values (4, 'Toronto, ON' );
Insert into INDEPENDENT_LABEL values (5, 'Burbank, CA');
Insert into INDEPENDENT_LABEL values (6, 'Memphis, TN');
Insert into INDEPENDENT_LABEL values (7, 'Nashville, TN');
Insert into INDEPENDENT_LABEL values (8, 'Orlando, FL');
Insert into INDEPENDENT_LABEL values (9, 'Chicago, IL');
Insert into INDEPENDENT_LABEL values (10, 'Hollywood, CA');
Insert into INDEPENDENT_LABEL values (11, 'Plano, TX');
Insert into INDEPENDENT_LABEL values (12, 'Orlando, FL');
Insert into INDEPENDENT_LABEL values (13, 'Nashville, TN');
Insert into INDEPENDENT_LABEL values (14, 'Columbus, OH');
Insert into INDEPENDENT_LABEL values (15, 'Austin, TX');
Insert into INDEPENDENT_LABEL values (16, 'Santa Monica, CA');
Insert into INDEPENDENT_LABEL values (17, 'Chicago, IL');
Insert into INDEPENDENT_LABEL values (18, 'New York, NY');
Insert into INDEPENDENT_LABEL values (19, 'San Diego, CA');
Insert into INDEPENDENT_LABEL values (20, 'Jacksonville, FL');


Insert into MAJOR_LABEL values (1, 'Miami , FL');
Insert into MAJOR_LABEL values (2, 'Manchester, England');
Insert into MAJOR_LABEL values (3, 'New York, NY');
Insert into MAJOR_LABEL values (4, 'Los Angeles, CA');
Insert into MAJOR_LABEL values (5, 'Chicago, IL');
Insert into MAJOR_LABEL values (6, 'Los Angeles, CA');
Insert into MAJOR_LABEL values (7, 'Austin, TX');
Insert into MAJOR_LABEL values (8, 'Malibu, CA');
Insert into MAJOR_LABEL values (9, 'Hollywood, CA');
Insert into MAJOR_LABEL values (10, 'Orlando, FL');
Insert into MAJOR_LABEL values (11, 'Nashville, TN');
Insert into MAJOR_LABEL values (12, 'Miami, FL');
Insert into MAJOR_LABEL values (13, 'Detroit,MI');
Insert into MAJOR_LABEL values (14, 'Tokyo,  Japan');
Insert into MAJOR_LABEL values (15, 'Pittsburgh, PA');
Insert into MAJOR_LABEL values (16, 'Beverly Hills, CA');
Insert into MAJOR_LABEL values (17, 'Toronto, ON');
Insert into MAJOR_LABEL values (18,'Honolulu, HI');
Insert into MAJOR_LABEL values (19, 'Tokyo, Japan');
Insert into MAJOR_LABEL values (20, 'Manchester, England');

Insert ALBUM_CREATOR values (1,1);
Insert ALBUM_CREATOR values (2,2);
Insert ALBUM_CREATOR values (3,3);
Insert ALBUM_CREATOR values (4,4);
Insert ALBUM_CREATOR values (5,5);
Insert ALBUM_CREATOR values (6,6);
Insert ALBUM_CREATOR values (7,7);
Insert ALBUM_CREATOR values (8,8);
Insert ALBUM_CREATOR values (9,9);
Insert ALBUM_CREATOR values (10,10);
Insert ALBUM_CREATOR values (11,11);
Insert ALBUM_CREATOR values (12,12);
Insert ALBUM_CREATOR values (13,13);
Insert ALBUM_CREATOR values (14,14);
Insert ALBUM_CREATOR values (15,15);
Insert ALBUM_CREATOR values (16,16);
Insert ALBUM_CREATOR values (17,17);
Insert ALBUM_CREATOR values (18,18);
Insert ALBUM_CREATOR values (19,19);
Insert ALBUM_CREATOR values (20,20);

commit;
